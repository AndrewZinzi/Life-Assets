# 💸 Discounted Cash Flow (DCF) Streamlit App

Upload your cash flow spreadsheet, choose your discount rate, and get the Net Present Value (NPV) instantly — with optional forecasting and a downloadable PDF report.

### 📦 Features:
- Upload Excel or CSV file
- Forecast future cash flows with growth rate
- Visualize data (chart + table)
- Export results to PDF

Built with Streamlit, Matplotlib, and FPDF.
